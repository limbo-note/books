package com.hbasebook.hush.model;

/**
 * Time frame for statistics.
 */
public enum TimeFrame {
  DAY, WEEK, MONTH
}